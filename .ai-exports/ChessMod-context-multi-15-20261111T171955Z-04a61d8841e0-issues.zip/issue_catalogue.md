# GitHub issue creation catalogue

Snapshot of repository-wide options, independent of issue filters.
Recheck GitHub before making any write: labels and milestones may change.

- Repository: ramou/ChessMod
- Default branch: 1.20.1
- Issues enabled: True
- Archived: False

## Labels (20)

| Label | Description | Colour |
| --- | --- | --- |
| 1.14.4 | — | 998be5 |
| 1.15.2 | — | b7376c |
| 1.16.5 | — | 1CFBA6 |
| 1.17.1 | — | DCCEC8 |
| 1.18.2 | — | 0052cc |
| 1.19.4 | — | EEE1F1 |
| 1.20.1 | — | E178C0 |
| 1.20.1 ChessWrench | — | fef2c0 |
| 1.21 | — | 008A4C |
| bug | Something isn't working | d73a4a |
| chessMod 0.7 | — | 0F7FF1 |
| documentation | Improvements or additions to documentation | 0075ca |
| duplicate | This issue or pull request already exists | cfd3d7 |
| enhancement | New feature or request | a2eeef |
| good first issue | Good for newcomers | 7057ff |
| help wanted | Extra attention is needed | 008672 |
| invalid | This doesn't seem right | e4e669 |
| question | Further information is requested | d876e3 |
| Research Milestone | — | 84F305 |
| wontfix | This will not be worked on | ffffff |

## Milestones (1)

| # | Milestone title (`gh --milestone` argument) | State | Due | Description |
| --- | --- | --- | --- | --- |
| 1 | 0.70 | open | — | — |

Not captured: Git tags (not issue labels); GitHub Projects V2 and project-specific fields; Organization issue types and forms; Repository write permissions and user-specific assignee eligibility.
